---
name: fsa-website-deploy
description: Deploy the Full Steam Ahead static website. Use when website files have been modified, including adding or updating pages, styles, assets, or articles. Orchestrates git commit and push, Docker container rebuild, sitemap maintenance, Google Search Console registration, and Cloudflare cache purging in the correct order.
---

# FSA Website Deploy

Deploy changes to the Full Steam Ahead website (`/home/debian/projects/fsa/fsa-website/`).

## When to Use

- Any file in `fsa-website/` has been added, removed, or modified
- New HTML pages, articles, styles, images, or scripts are ready to go live
- The sitemap needs updating to reflect new or removed pages
- A full end-to-end publish (git → Docker → Google → Cloudflare) is required

## Preconditions

- Working directory: `/home/debian/projects/fsa/fsa-website/`
- Docker and docker-compose available
- `.env` contains `CF_ZONE_ID` and `CF_API_TOKEN`
- Google Search Console OAuth token exists at `scripts/google_token.json`
- Git remote configured for `origin/master`

## Deploy Workflow

Run the steps below in order. Do not skip steps unless the user explicitly says so.

### 1. Inspect Changes

Determine what changed:

```bash
git -C /home/debian/projects/fsa/fsa-website/ status
git -C /home/debian/projects/fsa/fsa-website/ diff --stat
```

Identify:
- New `.html` pages added to the repo root
- Any `.html` pages removed from the repo root
- Modified files (styles, content, assets)

### 2. Update Sitemap (if pages added/removed)

If new root-level `.html` pages were added or removed, update `sitemap.xml` before committing.

Rules:
- Add a `<url>` block for each new root-level `.html` page
- Remove `<url>` blocks for deleted root-level `.html` pages
- Set `<lastmod>` to today's date (`YYYY-MM-DD`) for changed entries
- Use these defaults for new pages:
  - `changefreq`: `monthly` (use `daily` for frequently-updated pages like job boards)
  - `priority`: `0.5` for utility pages, `0.7` for high-traffic/new features, `1.0` for homepage
- Update the homepage `<lastmod>` to today's date on any deploy
- Articles inside `articles/` are **not** tracked individually in the sitemap (only `articles/` hub is listed)

After editing, validate the XML is well-formed.

### 3. Commit and Push

Stage only the files that actually changed (do not use `git add -A`):

```bash
git -C /home/debian/projects/fsa/fsa-website/ add <file1> <file2> ...
git -C /home/debian/projects/fsa/fsa-website/ commit -m "<concise message>"
git -C /home/debian/projects/fsa/fsa-website/ push origin master
```

### 4. Rebuild Docker Container

Build a fresh image and recreate the container:

```bash
docker compose -f /home/debian/projects/fsa/fsa-website/docker-compose.yml build --no-cache
docker rm -f fsa-website
docker compose -f /home/debian/projects/fsa/fsa-website/docker-compose.yml up -d
```

Verify it is running:

```bash
docker ps --filter "name=fsa-website" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
```

### 5. Submit Sitemap to Google Search Console

Run the submission script. Use `--sitemap-only` if only the sitemap was updated; omit the flag to also request indexing for all known URLs.

```bash
python3 /home/debian/projects/fsa/fsa-website/scripts/submit_to_google.py --sitemap-only
```

If the OAuth token is expired or missing, the script will open a browser flow on port `8888` and save a new token to `scripts/google_token.json`.

### 6. Purge Cloudflare Cache

Always run this last so visitors see the latest content immediately:

```bash
bash /home/debian/projects/fsa/fsa-website/scripts/purge_cloudflare.sh
```

## One-Shot Deploy Script

For hands-free deployments, execute the bundled script:

```bash
bash /home/debian/projects/fsa/fsa-website/.kilo/skills/fsa-website-deploy/scripts/deploy.sh
```

The script performs the full workflow: inspect → sitemap update (interactive) → commit/push → Docker rebuild → Google sitemap submit → Cloudflare purge.
